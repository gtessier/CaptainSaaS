//modified for Growh Hackers type theme
jQuery(document).ready(function ($) {

	      
    
    
     $('#thumbnail').change(function() {
     var thumb = $('#thumbnail').val();
	 $('#thumbprev').html("<img src = " + thumb + ">");
	 });


    
    

});