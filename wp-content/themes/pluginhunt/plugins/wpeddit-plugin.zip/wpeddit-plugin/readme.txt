Easy Polling Plugin
Plugin URI: http://pollingplugin.com/
Description: Easy WordPress Polling Plugin
WordPress website
Version: 2.5
Author: MYO
http://www.make-your-offer.com
---------------------------
Copyright 2012, Mike Stott, MYO